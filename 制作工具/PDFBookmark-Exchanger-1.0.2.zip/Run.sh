
java -Xms128m -Xmx2048m -jar PDFBookmark.jar
